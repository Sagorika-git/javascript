var count = 2;
function add_fields(){
    // Label

    // Creating the label element
    var lbl = document.createElement('label');

    // Element label text
    lbl.innerText = "Qualification "+count;

    // Creating the id of the lebel
    lbl_id = "Qualification-"+count;

    // Set the lavel id attribute and value
    lbl.setAttribute('id', lbl_id);

    var br1 = document.createElement('br');

    // appending the label
    document.body.appendChild(lbl);
    document.body.appendChild(br1);

    // Input Box

    var inp = document.createElement('input');


    inp.setAttribute("type", "text");


    var inp_id = "inp-"+count;

    inp.setAttribute("id", inp_id);

    var br2 = document.createElement('br');
    
    document.body.appendChild(inp);

    // Delete Button
    var delete_btn = document.createElement('button');
    delete_btn.innerText = "Delete";
    
    var delete_btn_id = 'del-btn-' + count;
    delete_btn.setAttribute('id', delete_btn_id);
    
    var del_inp = "delete_inp("+count+")";
    delete_btn.setAttribute('onclick', del_inp);
    document.body.appendChild(delete_btn);

    document.body.appendChild(br2);
    count++;
}

function delete_inp(inp_id){
    var n1 = 'Qualification-'+ inp_id;
    document.getElementById(n1).remove();
    var n2 = 'inp-'+ inp_id;
    document.getElementById(n2).remove();
    var n3 = 'del-btn-' + inp_id;
    document.getElementById(n3).remove();
}

function job_done(){
    var ck1 = document.getElementById("ck1");
    var job = document.getElementById("job");
    if(ck1.checked)
        job.style.textDecoration = "line-through";
    else
        job.style.textDecoration = "none";
}