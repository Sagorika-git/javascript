var count = 2;
function add_fields(){
    var lbl = document.createElement('label');
    lbl.innerText = "Qualification-"+count;
    var br1 = document.createElement('br');
    document.body.appendChild(br1);
    document.body.appendChild(lbl);
    var inp = document.createElement('input');
    inp.setAttribute("type", "text");
    var inp_id = "inp-"+count;
    count++;
    inp.setAttribute("id", inp_id);
    var br2 = document.createElement('br');
    document.body.appendChild(br2);
    document.body.appendChild(inp);
}